import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menustart',
  templateUrl: './menustart.component.html',
  styleUrls: ['./menustart.component.scss'],
})
export class MenustartComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}

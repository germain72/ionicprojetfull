import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menusecond',
  templateUrl: './menusecond.component.html',
  styleUrls: ['./menusecond.component.scss'],
})
export class MenusecondComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
